# Sample book register app for cloud deployment
